Drug Store is PHP based theme for Pharmacy Management.
Drug Store is a pharmacy management system developed with PHP. Drug Store theme is an affordable solution to help grow your business and track your store data like stock, purchases, billings and report, purchase report and so many things. 
It store all of your pharmacy data for easy retrieval and tracking including your Medicines, Employees, Customers, POS/Bill, Invoice, Purchase, Stock Adujstment, Accounting, Expenses, Attendence, Payroll, Attendance, Reports and Users. 
You can create multiple admin role. Manage all from one simple yet powerful application.

Your main code reside in upload directory. You have to upload every file from main directory to your server for properly work.
For info please refer documentation.

Thank you for purchasing Drug Store theme. If you have any questions that are beyond the scope of this help file and documentation, 
please feel free to contact us at pepdev.com or mail us at support@pepdev.com.

If you have already purchase Drug Store theme then please do not upgrade directly. Come on live chat at http://pepdev.com/.
For upgradatiPlease consult with us first then upgrade.