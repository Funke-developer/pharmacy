<?php


/**
 * security
 */
class Security
{
}