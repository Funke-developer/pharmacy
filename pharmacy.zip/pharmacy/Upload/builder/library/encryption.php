<?php
/**
* Encryption class
*/
final class Encryption {


}