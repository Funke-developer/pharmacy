<?php
/*This name will represent title in auto generated mail*/
define('NAME', 'Drug Store');
/*Domain name like www.yourdomain.com*/
define('URL', '');


/*Application Address*/
define('DIR_ROUTE', 'index.php?route=');
define('DIR', '');
define('DIR_APP', DIR.'app/');
define('DIR_BUILDER', DIR.'builder/');
define('DIR_VIEW', DIR_APP.'views/');
define('DIR_IMAGE', DIR.'public/images/');
define('DIR_UPLOADS', DIR.'public/uploads/');
define('DIR_STORAGE', DIR_BUILDER.'storage/');
define('DIR_LIBRARY', DIR_BUILDER.'library/');
define('DIR_VENDOR', DIR_BUILDER.'vendor/');
define('DIR_LANGUAGE', DIR_APP.'language/');


/** MySQL settings - You can get this info from your web host **/
/*MySQL database host*/
define('DB_HOSTNAME', 'localhost');
/*MySQL database username*/
define('DB_USERNAME', '');
/*MySQL database password*/
define('DB_PASSWORD', '');
/*MySQL database Name*/
define('DB_DATABASE', '');
/*Table Prefix*/
define('DB_PREFIX', 'ds_');


define('AUTH_KEY', 'A;u7qk;tA&lK|jU9i7QHx(3EX2sLcPf&n0NE1{wOPw5tgNfIo~VNOizaJZAi3D{U');
define('LOGGED_IN_SALT', '|0U0D)UJXG861aBWIyPYKd*5a)0T86U&&cvhZm#T8mP1tK29GvLvZgJC5OCj7UeD');
define('TOKEN', 'JqAC;3nnVa<}HQzj;GUV|6?B27uade8{qTE-QK#bmvg-2p0V}MD;%0w;gD}gsC)K');
define('TOKEN_SALT', 'QvDl>72fXqu0Dy;KbXkAf~XX-GLEzwEx*LLy1Wj%2W5<)Th0>LK3)v9tx5cUyi~h');
